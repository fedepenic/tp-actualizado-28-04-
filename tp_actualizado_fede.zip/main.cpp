#include <iostream>
#include "menu.h"

int main(){
    Menu menu_actual;
    menu_actual.iniciar_interfaz();
    return 0;
}